<template>
    <div class="ensemble">
        <div class="form">
            <Filter_form @search="updateFiltres" />
        </div>

        <div class="tabilation">
            <div class="tableau">
                <table>
                    <thead>
                        <tr>
                            <th>Créé par</th>
                            <th>Client</th>
                            <th>Date</th>
                            <th>Montant payé</th>
                            <th>Prix total</th>
                            <th>Option</th>
                            <th>Status</th>
                        </tr>
                    </thead>

                    <tbody>
                        <tr v-if="error">
                            <td colspan="6" style="color:red">
                                Impossible de charger les données.
                            </td>
                        </tr>

                        <tr v-else-if="resultsVentes.length === 0">
                            <td colspan="6">Aucune donnée disponible.</td>
                        </tr>

                        <tr 
                            v-for="vente in resultsVentes" 
                            :key="vente.id"
                        >
                            <td>{{ vente?.created_by?.username || "—" }}</td>
                            <td>{{ vente?.client?.customer_name || "—" }}</td>
                            <td>{{ formatDate(vente?.date) }}</td>
                            <td>{{ formatNumber(vente?.payee) }}</td>
                            <td>{{ formatNumber(vente?.prix_total) }}</td>
                            <td class="text-center">
                                <div class="dropdown-wrapper">
                                    <button 
                                        class="btn-icon" 
                                        :class="{ 'btn-icon--active': activeDropdown === vente.id }"
                                        @click="toggleDropdown(vente, $event)"
                                    >
                                        <i class="fa-solid fa-ellipsis-vertical"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <Dialog_facture 
        v-if="show_table"
        :vente="selectedVente"
        @closeFacture="show_table = false"
    />

    <Teleport to="body">
        <template v-if="activeDropdown !== null">
            <div 
                class="histo-dropdown"
                :style="dropdownStyle"
            >
                <!-- Flèche décorative -->
                <div class="histo-dropdown__arrow"></div>

                <div class="histo-dropdown__body">
                    <button 
                        class="histo-dropdown__item histo-dropdown__item--facture"
                        @click="openFactures(selectedDropdownVente); activeDropdown = null"
                    >
                        <span class="histo-dropdown__icon">
                            <i class="fa-solid fa-file-invoice"></i>
                        </span>
                        <span class="histo-dropdown__text">
                            <span class="histo-dropdown__title">Facture</span>
                            <span class="histo-dropdown__sub">Voir la facture</span>
                        </span>
                        <i class="fa-solid fa-chevron-right histo-dropdown__arrow-right"></i>
                    </button>

                    <div class="histo-dropdown__divider"></div>

                    <button 
                        class="histo-dropdown__item histo-dropdown__item--payment"
                        @click="openPayment(selectedDropdownVente); activeDropdown = null"
                    >
                        <span class="histo-dropdown__icon">
                            <i class="fa-solid fa-money-bill-wave"></i>
                        </span>
                        <span class="histo-dropdown__text">
                            <span class="histo-dropdown__title">Paiements</span>
                            <span class="histo-dropdown__sub">Gérer les paiements</span>
                        </span>
                        <i class="fa-solid fa-chevron-right histo-dropdown__arrow-right"></i>
                    </button>

                    <div class="histo-dropdown__divider"></div>

                    <button 
                        class="histo-dropdown__item histo-dropdown__item--envoyer_obr"
                        @click="envoyerObr(selectedDropdownVente); activeDropdown = null"
                    >
                        <!-- <span class="histo-dropdown__icon">
                            <i class="fa-solid fa-money-bill"></i>
                        </span> -->
                        <span class="histo-dropdown__text">
                            <span class="histo-dropdown__title">Envoyer dans l'OBR</span>
                            <span class="histo-dropdown__sub"></span>
                        </span>
                        <i class="fa-solid fa-chevron-right histo-dropdown__arrow-right"></i>
                    </button>
                </div>
            </div>
            <div class="histo-overlay" @click="activeDropdown = null"></div>
        </template>
    </Teleport>
</template>

<script>
import Filter_form from '@/components/filter_form.vue'
import Dialog_facture from '@/components/dialog_facture.vue'
import axios from 'axios';
import { toast } from "vue3-toastify";

export default {
    components: { Filter_form, Dialog_facture },

    data() {
        return {
            loading: false,
            error: false,
            show_table: false,
            selectedVente: null,
            selectedDropdownVente: null,
            search_query: "",
            activeDropdown: null,
            dropdownStyle: {}
        }
    },

    computed: {
        resultsVentes() {
            const ventes = this.$store.getters.historique?.results || [];
            if (!this.search_query) return ventes;
            const q = this.search_query.toLowerCase();
            return ventes.filter(v =>
                v?.client?.customer_name?.toLowerCase().includes(q) ||
                v?.date?.toString().includes(q) ||
                v?.payee?.toString().includes(q) ||
                v?.prix_total?.toString().includes(q)
            );
        }
    },

    methods: {
        openDialog() {
            this.capital_show = true;
        },

        getData() {
            this.loading = true;
            let url = 'ventes/';
            let allResults = [];
            const pageLoad = (link) => {
                axios
                    .get(link, this.headers)
                    .then(res => {
                        allResults = allResults.concat(res.data.results);
                        if (res.data.next) {
                            pageLoad(res.data.next);
                        } else {
                            this.$store.state.ventes = { results: allResults };
                        }
                    })
                    .catch(err => console.log("ERREUR :", err))
                    .finally(() => { this.loading = false; });
            };
            pageLoad(url);
        },

        openFactures(vente) {
            this.selectedVente = vente;
            this.show_table = true;
            this.activeDropdown = null;
        },

        openPayment(vente) {
            this.activeDropdown = null;
            this.$router.push({
                name: 'Paiements',
                params: { id: vente.id },
                query: { total: vente.prix_total, paye: vente.payee }
            });
        },
        envoyerObr(vente) {
            axios
                .get(`ventes/${vente.id}/envoyer-obr/`, this.headers)
                .then((response) => {
                    if (response.data?.status === 200 || response.data?.status === 201) {
                        this.toast.success("La vente est envoyée avec succès")
                    }
                })
        },

        updateFiltres(value) {
            this.search_query = value;
        },

        formatNumber(n) {
            if (!n && n !== 0) return "—";
            return new Intl.NumberFormat().format(n);
        },

        formatDate(d) {
            if (!d) return "—";
            return new Date(d).toLocaleDateString();
        },

        toggleDropdown(vente, event) {
            if (this.activeDropdown === vente.id) {
                this.activeDropdown = null;
                this.selectedDropdownVente = null;
                return;
            }

            const btn = event.currentTarget;
            const rect = btn.getBoundingClientRect();
            const menuWidth = 220;
            const menuHeight = 140;
            const spaceBelow = window.innerHeight - rect.bottom;
            const spaceRight = window.innerWidth - rect.right;

            const top = spaceBelow < menuHeight
                ? rect.top - menuHeight - 8
                : rect.bottom + 8;

            const left = spaceRight < menuWidth
                ? rect.right - menuWidth
                : rect.left;

            this.dropdownStyle = {
                position: 'fixed',
                top: `${top}px`,
                left: `${left}px`,
                zIndex: '99999'
            };

            this.selectedDropdownVente = vente;
            this.activeDropdown = vente.id;
        },
    },

    async mounted() {
        this.loading = true;
        try {
            await this.$store.dispatch('fetchAllHistorique');
        } catch (e) {
            console.error("Erreur chargement historique :", e);
            this.error = true;
        } finally {
            this.loading = false;
        }
    }
}
</script>

<style src="@/style.css"></style>