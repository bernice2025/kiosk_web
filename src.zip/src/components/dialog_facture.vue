<template>
  <div class="dialog-overlay">
    <div class="dialog-content">
      <div class="dialog-header">
        <h2>Facture N° {{ vente.id }}</h2>
        <i class="fa-solid fa-xmark" @click="$emit('closeFacture')"></i>        
      </div>
      <div class="body">
      <div class="client-company">
        <div class="client">
            <h4>Facturé à</h4>
            <h3>{{ vente.client.customer_name }}</h3>
            <span>Téléphone : {{ vente.client.tel }}</span>
            <span>NIF : {{ vente.client.customer_TIN }}</span>
            <span>Adresse : {{ vente.client.customer_address }}</span>
            <span>Assujetti à la TVA : {{ vente.client.vat_customer_payer == 1 ? "Oui" : "Non" }}</span>
        </div>
        <div class="company">
            <h3>{{ $store.state.kiosks.results[0]?.name }}</h3>
            <span>{{ $store.state.kiosks.results[0]?.phone }} - {{ $store.state.kiosks.results[0]?.email }}</span>
            <span>
              {{ $store.state.kiosks.results[0]?.address }}
            </span>
            <span>
              R.C: {{ $store.state.kiosks.results[0]?.tp_trade_number }} NIF : {{ $store.state.kiosks.results[0]?.tp_TIN }}
            </span>
            <span>
              Assujetti à la TVA : {{ $store.state.kiosks.results[0]?.vat_taxpayer }}
            </span>
            <span>
              Centre fiscal : {{ $store.state.kiosks.results[0]?.tp_fiscal_center }}
            </span>
            <span>
              Secteur d'activité : {{ $store.state.kiosks.results[0]?.tp_activity_sector }}
            </span>
        </div>
      </div>
      <div class="dialog-body">
        <div class="facture-info">
          <p><strong>Date:</strong> {{ formatDate(vente.date) }}</p>
          <p><strong>Total:</strong> {{ formatNumber(vente.prix_total) }} BIF</p>
        </div>

        <div class="products-section">
          <h3>Détails des produits :</h3>
          <table class="products-table">
            <thead>
              <tr>
                <th>Produit</th>
                <th>Quantité</th>
                <th>Prix unitaire</th>
                <th>PVHTVA</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="produit in vente.produits" :key="produit.id">
                <td>{{ produit.nom }}</td>
                <td>{{ produit.quantite }}</td>
                <td>{{ formatNumber(produit.prix?.prix) }}</td>
                <td>{{ formatNumber(produit.prix?.prix * produit.quantite) }}</td>
              </tr>
            </tbody>
          </table>
        </div>

        <div class="totals">
          <div class="total-line">
            <span>Sous-total:</span>
            <span>{{ formatNumber(calculateSubTotal()) }}</span>
          </div>
          <div class="total-line">
            <span>TVA (18%):</span>
            <span>{{ formatNumber(calculateTVA()) }}</span>
          </div>
          <div class="total-line grand-total">
            <span>Total:</span>
            <span>{{ formatNumber(vente.prix_total) }}</span>
          </div>
        </div>
      </div>
      </div>
      <div class="monBouton">
        <button class="button" @click="$emit('closeFacture')">Imprimer</button>
      </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  props: {
    vente: {
      type: Object,
      required: true,
    },
  },
  methods: {
    calculateSubTotal() {
      return this.vente.produits.reduce((total, produit) => 
        total + (produit.prix?.prix * produit.quantite), 0)
    },
    calculateTVA() {
      return this.calculateSubTotal() * 0.18
    },
    getData() {
      this.loading = true
      axios
        .get('ventes/', {
          ...this.headers,
          params: {
            include: 'produits'
          }
        })
        .then((response) => {
          this.$store.state.ventes = response.data
        })
        .catch((error) => {
          console.error("AN ERROR OCCURED: ", error.response?.data)
        })
        .finally(() => {
          this.loading = false
        });
    },
    getKiosks() {
      this.loading = true
      axios
        .get('kiosks/', this.headers)
        .then((response) => {
          this.$store.state.kiosks = response.data
        })
        .catch((error) => {
          console.log("ERROR :", error.response?.data)
        })
        .finally(() => {
          this.loading = false
        })
    }
  },
  mounted() {
    this.getData();
    this.getKiosks();
  }
}
</script>

<style scoped src="@/dialog_style.css"></style>